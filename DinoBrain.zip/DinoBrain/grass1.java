import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class grass1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class grass1 extends Tileset
{
    /**
     * Act - do whatever the grass1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public grass1()
    {
        super("gras1.png");
        getImage().scale(120, 48);
    }
}
