import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot, and MouseInfo)

public class DinoPlayer extends Actor
{
    // Variabel Fisika & Gerakan
    private int speed = 4;
    private int vSpeed = 0;
    private int acceleration = 1;
    private int jumpStrength = -15;
    
    // Status Karakter
    private boolean isDead = false;
    private int lives = 3;
    
    // Animasi
    private GreenfootImage[] walkImages;
    private GreenfootImage[] jumpImages;
    private GreenfootImage[] deadImages;
    
    // Menggunakan Counter Frame (Aman dari error SimpleTimer)
    private int animCounter = 0;
    private int walkIndex = 0;
    private int jumpIndex = 0;
    private int deadIndex = 0;

    public DinoPlayer() {
        // Inisialisasi Array Animasi
        walkImages = new GreenfootImage[3];
        walkImages[0] = new GreenfootImage("walk2.png");
        walkImages[1] = new GreenfootImage("walk3.png");
        walkImages[2] = new GreenfootImage("walk4.png");
        
        jumpImages = new GreenfootImage[5];
        for (int i = 0; i < 5; i++) {
            jumpImages[i] = new GreenfootImage("jump" + (i + 1) + ".png");
        }
        
        deadImages = new GreenfootImage[3];
        for (int i = 0; i < 3; i++) {
            deadImages[i] = new GreenfootImage("dead" + (i + 1) + ".png");
        }

        setImage(walkImages[0]);
    }

    public void act()
    {
        if (isDead) {
            playDeadAnimation();
            return;
        }
        
        checkMovement();
        fall();
        checkCollisions();
    }
    
    // Kontrol Pergerakan Kiri-Kanan & Animasi Jalan
    private void checkMovement() {
        boolean moving = false;
        
        if (Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a")) {
            move(-speed);
            moving = true;
        }
        if (Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) {
            move(speed);
            moving = true;
        }
        
        // Tombol Lompat
        if ((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) && onGround()) {
            jump();
        }
        
        // Jalankan Animasi Berjalan atau Diam
        if (onGround()) {
            if (moving) {
                animateWalk();
            } else {
                setImage(walkImages[0]);
                animCounter = 0;
            }
        } else {
            animateJump();
        }
    }
    
    // Aksi Lompat
    private void jump() {
        vSpeed = jumpStrength;
        fall();
    }
    
    // Sistem Gravitasi & Jatuh
    private void fall() {
        setLocation(getX(), getY() + vSpeed);
        vSpeed += acceleration;
    
        if (getY() > getWorld().getHeight() - 30) {
            setLocation(getX(), getWorld().getHeight() - 50);
            vSpeed = 0;
        }
    }
    
    // Cek Apakah Berada di Atas Ground / Platform
    public boolean onGround() {
        Actor ground = getOneObjectAtOffset(0, getImage().getHeight() / 2, Ground.class);
        Actor platform = getOneObjectAtOffset(0, getImage().getHeight() / 2, Platform.class);
        
        if (ground != null || platform != null) {
            Actor target = (ground != null) ? ground : platform;
            setLocation(getX(), target.getY() - (target.getImage().getHeight() / 2) - (getImage().getHeight() / 2));
            vSpeed = 0;
            return true;
        }
        return false;
    }
    
    // Cek Tabrakan dengan Musuh/Duri (Diperbaiki ke Spikes.class)
    private void checkCollisions() {
        if (isTouching(spikes.class)) {
            die();
        }
    }
    
    // Method untuk Memicu Kematian
    public void die() {
        isDead = true;
        deadIndex = 0;
        animCounter = 0;
    }
    
    // Animasi Berjalan (Berbasis Frame)
    private void animateWalk() {
        animCounter++;
        if (animCounter > 8) { // Semakin kecil angkanya, semakin cepat animasinya
            walkIndex = (walkIndex + 1) % walkImages.length;
            setImage(walkImages[walkIndex]);
            animCounter = 0;
        }
    }
    
    // Animasi Melompat
    private void animateJump() {
        if (vSpeed < 0) {
            setImage(jumpImages[0]);
        } else {
            setImage(jumpImages[Math.min(jumpIndex, jumpImages.length - 1)]);
            animCounter++;
            if (animCounter > 10) {
                if (jumpIndex < jumpImages.length - 1) {
                    jumpIndex++;
                }
                animCounter = 0;
            }
        }
    }
    
    // Animasi Mati (Berbasis Frame)
    private void playDeadAnimation() {
        animCounter++;
        if (animCounter > 12) {
            if (deadIndex < deadImages.length) {
                setImage(deadImages[deadIndex]);
                deadIndex++;
            } else {
                // Animasi mati selesai, Anda bisa biarkan diam atau tambahkan aksi lain di sini
            }
            animCounter = 0;
        }
    }
}