import greenfoot.*;

public class Level1World extends World
{
    private int score = 0;
    private int lives = 3;
    private int time = 180;

    private int timerCounter = 0;

    private GameHUD hud;
    private QuizPanel quizPanel;
    private MysteryBox currentBox;

    private boolean quizOpen = false;
    private boolean gameOver = false;

    public Level1World()
    {
        super(1024, 576, 1);

        GreenfootImage bg =
            new GreenfootImage("latarpagi.jpg");

        bg.scale(1024, 576);
        setBackground(bg);

        prepareHUD();
        prepareGame();
    }

    // HUD
    private void prepareHUD()
    {
        hud = new GameHUD();

        addObject(hud, 512, 32);

        addObject(
            new ButtonsPaused(), 950, 35
        );

        addObject(
            new ButtonsHome(), 990, 35
        );
    }

    // MENYUSUN LEVEL
    private void prepareGame()
    {
        // Dino
        addObject(new Dinowalk(), 100, 450);

        // TANAH AWAL
        addGrassRow(60, 280, 530);

        // PLATFORM PERTAMA
        addObject(new grass1(), 340, 420);
        addObject(new grass1(), 450, 420);

        // TANAH TENGAH
        addGrassRow(500, 650, 530);

        // PLATFORM TINGGI
        addObject(new grass1(), 690, 360);
        addObject(new grass1(), 800, 360);

        // TANAH AKHIR
        addGrassRow(880, 1020, 530);

        // KOIN
        addObject(new coin(), 200, 460);
        addObject(new coin(), 260, 460);
        addObject(new coin(), 340, 350);
        addObject(new coin(), 450, 350);
        addObject(new coin(), 690, 290);
        addObject(new coin(), 800, 290);

        // MYSTERY BOX
        addObject(new MysteryBox(1), 570, 450);
        addObject(new MysteryBox(2), 740, 290);
        addObject(new MysteryBox(3), 940, 450);
        
        addObject(new spikes(), 630, 500);
    }

    private void addGrassRow(
        int startX, int endX, int y)
    {
        for (int x = startX; x <= endX; x += 110)
        {
            addObject(new grass(), x, y);
        }
    }

    // MENAMBAHKAN SCORE
    public void addScore(int value)
    {
        score += value;
        updateHUD();
    }

    // MENGURANGI NYAWA
    public void loseLife()
    {
        if (lives > 0)
        {
            lives--;
            updateHUD();
        }

        if (lives <= 0)
        {
            endGame();
        }
    }

    // MEMBUKA MYSTERY BOX
    public void startQuiz(
        MysteryBox box, int number)
    {
        if (quizOpen || gameOver)
            return;

        quizOpen = true;
        currentBox = box;

        quizPanel = new QuizPanel(number);

        addObject(quizPanel, 512, 285);
    }

    // MEMERIKSA JAWABAN
    public void answerQuiz(
        int question, int answer)
    {
        boolean correct = false;

        if (question == 1 && answer == 1)
            correct = true;

        if (question == 2 && answer == 2)
            correct = true;

        if (question == 3 && answer == 2)
            correct = true;

        if (correct)
        {
            score += 50;
            showText(
                "BENAR! +50 SCORE",
                512, 490
            );
        }
        else
        {
            loseLife();

            showText(
                "SALAH! -1 NYAWA",
                512, 490
            );
        }

        if (currentBox != null)
        {
            removeObject(currentBox);
            currentBox = null;
        }

        removeObject(quizPanel);
        quizPanel = null;

        quizOpen = false;

        updateHUD();
    }

    // UPDATE HUD
    private void updateHUD()
    {
        hud.updateData(score, lives, time);
    }

    // TIMER
    public void act()
    {
        if (gameOver || quizOpen)
            return;

        timerCounter++;

        if (timerCounter >= 60)
        {
            timerCounter = 0;

            if (time > 0)
            {
                time--;
                updateHUD();
            }
            else
            {
                endGame();
            }
        }
    }

    // GAME OVER
    private void endGame()
    {
        gameOver = true;

        showText(
            "GAME OVER!",
            512, 260
        );

        showText(
            "SCORE: " + score,
            512, 310
        );

        Greenfoot.stop();
    }
}