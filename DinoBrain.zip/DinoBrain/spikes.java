import greenfoot.*;

public class spikes extends Tileset
{
    public spikes()
    {
        super("spike.png");
        getImage().scale(64, 48);
    }

    public void act()
    {
        if (isTouching(Dinowalk.class))
        {
            Level1World world =
                (Level1World)getWorld();

            world.loseLife();

            world.removeObject(this);
        }
    }
}