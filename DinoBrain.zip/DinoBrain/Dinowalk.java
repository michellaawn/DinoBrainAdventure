import greenfoot.*;

public class Dinowalk extends Actor
{
    private GreenfootImage[] frames = new GreenfootImage[4];

    private int animationCounter = 0;
    private int currentFrame = 0;

    public Dinowalk()
    {
        // Memuat semua gambar Dino
        frames[0] = new GreenfootImage("walk1.png");
        frames[1] = new GreenfootImage("walk2.png");
        frames[2] = new GreenfootImage("walk3.png");
        frames[3] = new GreenfootImage("walk4.png");

        // Mengatur ukuran semua frame
        for (int i = 0; i < frames.length; i++)
        {
            frames[i].scale(90, 90);
        }

        setImage(frames[0]);
    }

    public void act()
    {
        animationCounter++;
        if (animationCounter >= 5)
        {
            animationCounter = 0;
            currentFrame = (currentFrame + 1) % frames.length;
            setImage(frames[currentFrame]);
        }
    }
}