import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class coin here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class coin extends Tileset
{
    public coin()
    {
        super("coin.png");
        getImage().scale(32, 32);
    }

    public void act()
    {
        if (isTouching(Dinowalk.class))
        {
            Level1World world =
                (Level1World)getWorld();

            world.addScore(10);

            getWorld().removeObject(this);
        }
    }
}
