import greenfoot.*;

public class QuizPanel extends Actor
{
    private int questionNumber;
    private boolean answered = false;

    public QuizPanel(int number)
    {
        questionNumber = number;
        drawQuestion();
    }

    private void drawQuestion()
    {
        GreenfootImage img = new GreenfootImage(650, 330);
        img.setColor(new Color(55, 40, 75));
        img.fillRect(0, 0, 650, 330);
        
        img.setColor(new Color(255, 230, 190));
        img.fillRect(8, 8, 634, 314);

        img.setColor(new Color(90, 55, 35));
        img.setFont(new Font("Arial", 27));
        img.drawString("MYSTERY BOX!", 210, 48);

        img.setFont(new Font("Arial", 20));
        img.setColor(Color.BLACK);

        if (questionNumber == 1)
        {
            img.drawString("Perhatikan pola gambar berikut!", 65, 100);

            img.setFont(new Font("Arial", 35));
            img.drawString("O     ^     O     ^     ?", 120, 165);

            img.setFont(new Font("Arial", 19));
            img.drawString("A. Lingkaran", 45, 230);
            img.drawString("B. Segitiga", 245, 230);
            img.drawString("C. Bintang", 440, 230);
        }
        else if (questionNumber == 2)
        {
            img.drawString("Perhatikan waktu pada jam!", 95, 100);

            img.setFont(new Font("Arial", 35));
            img.drawString("03:00", 245, 165);

            img.setFont(new Font("Arial", 19));
            img.drawString("Berapa menit dalam 1 jam?", 105, 210);
            img.drawString("A. 30", 70, 270);
            img.drawString("B. 60", 260, 270);
            img.drawString("C. 100", 450, 270);
        }
        else if (questionNumber == 3)
        {
            img.drawString("Hitung jumlah koin berikut!", 95, 100);

            img.setFont(new Font("Arial", 30));
            img.drawString("12 + 8 = ?", 225, 165);

            img.setFont(new Font("Arial", 19));
            img.drawString("A. 18", 70, 245);
            img.drawString("B. 20", 260, 245);
            img.drawString("C. 22", 450, 245);
        }

        img.setFont(new Font("Arial", 16));
        img.setColor(new Color(90, 70, 50));
        img.drawString("Tekan tombol 1, 2, atau 3 untuk menjawab", 135, 300);

        setImage(img);
    }

    public void act()
    {
        if (answered)
            return;

        String key = Greenfoot.getKey();

        if (key == null)
            return;

        int answer = 0;

        if (key.equals("1"))
            answer = 1;
        else if (key.equals("2"))
            answer = 2;
        else if (key.equals("3"))
            answer = 3;

        if (answer != 0)
        {
            answered = true;

            Level1World world = (Level1World)getWorld();
            world.answerQuiz(questionNumber, answer);
        }
    }
}