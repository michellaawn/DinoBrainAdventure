import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class grass here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class grass extends Tileset
{
    public grass()
    {
        super("grass.png");
        getImage().scale(120, 64);
    }
}
