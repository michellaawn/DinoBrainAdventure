import greenfoot.*;

public class MysteryBox extends Actor
{
    private int questionNumber;
    private boolean opened = false;

    public MysteryBox(int number)
    {
        questionNumber = number;

        GreenfootImage img =
            new GreenfootImage("MysteryBox.png");

        img.scale(64, 64);
        setImage(img);
    }

    public void act()
    {
        if (!opened &&
            isTouching(Dinowalk.class))
        {
            opened = true;

            Level1World world =
                (Level1World)getWorld();

            world.startQuiz(this, questionNumber);
        }
    }
}