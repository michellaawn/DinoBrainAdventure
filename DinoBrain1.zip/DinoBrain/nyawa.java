import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class nyawa here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class nyawa extends Tileset
{
    /**
     * Act - do whatever the nyawa wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public nyawa()
    {
        super("love.png");
        getImage().scale(32, 32);
    }
}
