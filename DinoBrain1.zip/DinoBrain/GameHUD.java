import greenfoot.*;

public class GameHUD extends Actor
{
    private GreenfootImage heart;
    private GreenfootImage coin;
    private GreenfootImage clock;

    private int score = 0;
    private int lives = 3;
    private int time = 180;

    public GameHUD()
    {
        heart = new GreenfootImage("love.png");
        coin = new GreenfootImage("coin.png");
        clock = new GreenfootImage("timee2.png");

        heart.scale(28, 28);
        coin.scale(28, 28);
        clock.scale(28, 28);

        drawHUD();
    }

    public void updateData(int s, int l, int t)
    {
        score = s;
        lives = l;
        time = t;

        drawHUD();
    }

    private void drawHUD()
    {
        GreenfootImage img = new GreenfootImage(1024, 65);
        img.setColor(new Color(20, 30, 75, 220));
        img.fillRect(15, 5, 990, 55);

        img.setFont(new Font("Arial", 19));
        img.setColor(Color.WHITE);

        img.drawString("LEVEL 1", 430, 38);

        img.drawImage(coin, 40, 18);
        img.drawString("SCORE: " + score, 75, 40);

        img.drawImage(heart, 250, 18);
        img.drawString("x " + lives, 285, 40);

        img.drawImage(clock, 700, 18);
        img.drawString(
            String.format("%02d:%02d", time / 60, time % 60),
            735, 40
        );

        setImage(img);
    }
}