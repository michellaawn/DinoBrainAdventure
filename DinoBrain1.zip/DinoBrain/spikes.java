import greenfoot.*;

public class spikes extends Actor
{
    public spikes()
    {
        // Sesuaikan ukuran duri jika terlalu besar/kecil
        GreenfootImage img = getImage();
        if (img != null) {
            img.scale(70, 35);
            setImage(img);
        }
    }

    public void act()
    {
        checkCollision();
    }

    private void checkCollision()
    {
        // Cek apakah Dino menyentuh duri
        Actor dino = getOneIntersectingObject(Dino.class);
        if (dino != null) {
            // Ambil referensi World dan panggil loseLife() di Level1World
            World world = getWorld();
            if (world instanceof Level1World) {
                Level1World level1 = (Level1World) world;
                level1.loseLife(); // Mengurangi nyawa dan cek Game Over
            }
            
            // Beri sedikit jeda atau pindahkan posisi Dino kembali ke awal agar tidak langsung mati beruntun
            dino.setLocation(60, 340); 
        }
    }
}