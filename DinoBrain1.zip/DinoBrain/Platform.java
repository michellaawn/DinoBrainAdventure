
import greenfoot.*;

public class Platform extends Actor
{
    public Platform(
        String imageName,
        int width,
        int height)
    {
        GreenfootImage image =
            new GreenfootImage(imageName);

        image.scale(width, height);

        setImage(image);
    }
}
