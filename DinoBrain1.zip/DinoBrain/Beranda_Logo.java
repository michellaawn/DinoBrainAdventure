import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Beranda_Logo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Beranda_Logo extends Actor
{
    /**
     * Act - do whatever the Beranda_Logo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
