import greenfoot.*;  

public class ButtonsPaused extends Buttons
{
    public ButtonsPaused() {
        GreenfootImage img = getImage();
        img.scale(40, 40);
        
        setImage(img);
    }

    public void act()
    {
        if (Greenfoot.mouseClicked(this)) {
            Greenfoot.stop();
        }
    }
}