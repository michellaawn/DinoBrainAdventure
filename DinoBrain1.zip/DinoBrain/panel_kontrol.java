import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class panel_kontrol here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class panel_kontrol extends tutorial
{
    /**
     * Act - do whatever the panel_kontrol wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
    }
}
