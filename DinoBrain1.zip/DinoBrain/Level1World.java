import greenfoot.*;

public class Level1World extends World
{
    private int score = 0;
    private int lives = 3; 
    private int timerCounter = 0;
    private int seconds = 0;
    
    private QuizPanel quizPanel;
    private MysteryBox currentBox;
    private boolean quizOpen = false;
    private boolean gameOver = false; 
    
    public Level1World()
    {
        super(850, 450, 1); 
        GreenfootImage bg = new GreenfootImage("latarpagi.jpg");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
        prepareGame();
        updateHUD();
    }
    
    public void act()
    {
        if (!gameOver && !quizOpen) {
            updateHUD();
        }
    }
    
    private void prepareGame()
    {
        addObject(new Tree(), 80, 280);
        addObject(new air(), 340, 445);
        
        for (int x = 0; x <= 280; x += 60) {
            addObject(new grass2(), x, 430);
        }
    
        addObject(new grass2(), 430, 430);
        addObject(new grass2(), 480, 430);
        addObject(new spikes(), 560, 435);
        for (int x = 620; x <= 850; x += 60) {
        addObject(new grass2(), x, 430);
        }
        
        addObject(new grass2(), 370, 310);
        addObject(new grass2(), 430, 310);
        addObject(new MysteryBox(1), 400, 255);
        addObject(new grass2(), 730, 270);
        addObject(new grass2(), 790, 270);        
        addObject(new Dino(), 60, 350);
        addObject(new coin(), 220, 380);
        addObject(new coin(), 250, 380);
        addObject(new coin(), 430, 380);
        addObject(new coin(), 460, 380);
        addObject(new coin(), 490, 380);
        addObject(new coin(), 745, 220);
        addObject(new coin(), 775, 220);
        addObject(new coin(), 690, 380);
        addObject(new coin(), 720, 380);
        addObject(new coin(), 750, 380);
        addObject(new grass1(), 280, 430); // Menumpuk di ujung kiri sebelum air
        addObject(new grass1(), 390, 430); // Di sekitar area tengah
        addObject(new grass1(), 520, 430); // Menumpuk di sebelah kiri duri / awal tanah kanan
        addObject(new grass1(), 850, 430);
        
        addObject(new dggrass(), 313, 310);
        
    
    }
    
    private void updateHUD()
    {
        showText("Nyawa: " + lives, 60, 25);
        showText("Score: " + score, 180, 25);
        showText("Time: " + seconds + "s", getWidth() - 70, 25);
    }
    
    public void addScore (int value)
    {
        score += value;
        updateHUD();
    }
    
    public void loseLife()
    {
        if (gameOver) return;
        
        lives--;
        updateHUD();
        
        if (lives <= 0){
            gameOver = true;
            showText("GAME OVER", getWidth()/2, getHeight()/2);
            Greenfoot.stop();
        }
    }
    
    public void startQuiz (MysteryBox box, int number)
    {
        if(quizOpen || gameOver) return;
        
        quizOpen = true;
        currentBox = box; 
        quizPanel = new QuizPanel(number);
        
        addObject(quizPanel, getWidth()/2, getHeight()/2);
    }
    
    public void answerQuiz(int question, int answer)
    {
        if(!quizOpen || gameOver) return;
        
        boolean correct = false;
        
        if (question == 1 && answer == 1) correct = true;
        if (question == 2 && answer == 2) correct = true;
        if (question == 3 && answer == 2) correct = true;

        if (correct) {
            score += 50; 
            showText("BENAR! +50 SCORE", getWidth() / 2, getHeight() - 50);
        } else {
            loseLife(); 
            showText("SALAH! -1 NYAWA", getWidth() / 2, getHeight() - 50);
        }

        if (currentBox != null) {
            removeObject(currentBox);
            currentBox = null;
        }

        if (quizPanel != null) {
            removeObject(quizPanel);
            quizPanel = null;
        }

        quizOpen = false;
        updateHUD();
    }
    
    public int getScore()
    {
        return score;
    }
    
    public int getLives()
    {
        return lives;
    }
}