import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class next here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class next extends dialog
{
    private box kotakDialog;

    public next(box kotakDialog, String fileGambar)
    {
        this.kotakDialog = kotakDialog;
        
        GreenfootImage img = new GreenfootImage(fileGambar); 
        // img.scale(120, 45); // Sesuaikan ukuran tombol jika perlu
        setImage(img);
    }

    public void act()
    {
        // Jika tombol ini diklik, suruh kotak dialog lanjut teks
        if (Greenfoot.mouseClicked(this))
        {
            kotakDialog.lanjutTeks(); 
        }
    }
}

