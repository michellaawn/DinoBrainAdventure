import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class start here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Start extends Beranda_Logo
{
    /**
     * Act - do whatever the start wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Start()
    {
        GreenfootImage img = new GreenfootImage(getImage());
        int lebarBaru = 150;
        int tinggiBaru = img.getHeight() * lebarBaru / img.getWidth();
        img.scale(lebarBaru, tinggiBaru);
        setImage(img);// Add your action code here.
    }
    public void act()
    {
    if (Greenfoot.mouseClicked(this))
    {
        Greenfoot.setWorld(new GAMESTART());
    }
    }
}
