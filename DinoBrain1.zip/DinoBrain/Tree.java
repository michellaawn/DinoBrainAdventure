import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Tree here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Tree extends Actor
{
    /**
     * Act - do whatever the Tree wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Tree()
    {
        GreenfootImage img = new GreenfootImage("pohon.png"); 
        img.scale(240, 260);
        
        setImage(img);
    }
    public void act()
    {
        // Add your action code here.
    }
}
