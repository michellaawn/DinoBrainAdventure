import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class LearnGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class LearnGame extends World
{

    /**
     * Constructor for objects of class LearnGame.
     * 
     */
    public LearnGame()
    {    
        super(800, 450, 1);
        GreenfootImage bg = new GreenfootImage("latarpagi.jpg");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
        panel_kontrol panel = new panel_kontrol();
        addObject(panel, getWidth()/2, getHeight()/2);
        
        tombol_ok  btnOK = new tombol_ok(panel);
        addObject(btnOK, (getWidth()/2) + 180, (getHeight()/2) + 120);
    }
}
