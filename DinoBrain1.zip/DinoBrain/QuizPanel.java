
import greenfoot.*;

public class QuizPanel extends Actor
{
    private int questionNumber;

    private boolean answered = false;

    private int quizTime = 10;
    private int frameCounter = 0;

    public QuizPanel(int number)
    {
        questionNumber = number;

        if (number == 1)
        {
            setImage("quiz1.png");
        }
        else if (number == 2)
        {
            setImage("quiz2.png");
        }
        else if (number == 3)
        {
            setImage("quiz3.png");
        }
        getImage().scale(620, 390);
    }

    public void act()
    {
        if (answered)
            return;

        frameCounter++;

        if (frameCounter >= 60)
        {
            frameCounter = 0;
            quizTime--;

            if (quizTime <= 0)
            {
                submitAnswer(0);
                return;
            }
        }

        if (Greenfoot.mouseClicked(this))
        {
            MouseInfo mouse = Greenfoot.getMouseInfo();

            if (mouse == null)
                return;

            int mouseX = mouse.getX() - getX();
            int mouseY = mouse.getY() - getY();

            if (mouseX >= -265 && mouseX <= -115 &&
                mouseY >= 75 && mouseY <= 145)
            {
                submitAnswer(1);
            }

            else if (mouseX >= -75 && mouseX <= 75 &&
                     mouseY >= 75 && mouseY <= 145)
            {
                submitAnswer(2);
            }

            else if (mouseX >= 115 && mouseX <= 265 &&
                     mouseY >= 75 && mouseY <= 145)
            {
                submitAnswer(3);
            }
        }
    }

    private void submitAnswer(int answer)
    {
        if (answered)
            return;

        answered = true;

        Level1World world =
            (Level1World)getWorld();

        world.answerQuiz(
            questionNumber,
            answer
        );
    }
}
