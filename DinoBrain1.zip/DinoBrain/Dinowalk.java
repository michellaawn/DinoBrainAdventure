import greenfoot.*;

public class Dinowalk extends Actor
{
    private GreenfootImage[] frames = new GreenfootImage[4];
    private int animationCounter = 0;
    private int currentFrame = 0;

    private int vSpeed = 0;          // Kecepatan vertikal (gravitasi)
    private int acceleration = 1;    // Besarnya tarikan gravitasi
    private int speed = 4;           // Kecepatan jalan ke samping
    private boolean isJumping = false;

    public Dinowalk()
    {
        // Memuat semua gambar Dino dan mengatur ukurannya
        frames[0] = new GreenfootImage("walk1.png");
        frames[1] = new GreenfootImage("walk2.png");
        frames[2] = new GreenfootImage("walk3.png");
        frames[3] = new GreenfootImage("walk4.png");

        for (int i = 0; i < frames.length; i++) {
            frames[i].scale(50, 50); // Ukuran disesuaikan agar pas di atas tileset
        }

        setImage(frames[0]);
    }

    public void act()
    {
        checkMovement();
        applyGravity();
        checkCollision();
    }

    private void checkMovement()
    {
        boolean moving = false;

        // Kontrol Kiri / Kanan
        if (Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) {
            setLocation(getX() + speed, getY());
            moving = true;
        }
        if (Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a")) {
            setLocation(getX() - speed, getY());
            moving = true;
        }

        // Kontrol Lompat (Space / Up / W)
        if ((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up") || Greenfoot.isKeyDown("w")) && !isJumping) {
            vSpeed = -15; // Kekuatan lompat ke atas
            isJumping = true;
        }

        // Animasi berjalan saat bergerak
        if (moving && !isJumping) {
            animationCounter++;
            if (animationCounter >= 6) {
                animationCounter = 0;
                currentFrame = (currentFrame + 1) % frames.length;
                setImage(frames[currentFrame]);
            }
        } else if (!isJumping) {
            setImage(frames[0]); 
        }
    }

    private void applyGravity()
    {
        setLocation(getX(), getY() + vSpeed);
        vSpeed += acceleration; // Tambah kecepatan jatuh karena gravitasi
    }

    private void checkCollision()
    {
        // Mendeteksi apakah Dino menginjak objek grass2
        Actor ground = getOneIntersectingObject(grass2.class);
        if (ground != null) {
            int groundHeight = ground.getImage().getHeight();
            int dinoHeight = getImage().getHeight();
            
            // Menghitung posisi Y yang pas persis di atas permukaan rumput
            int newY = ground.getY() - (groundHeight / 2) - (dinoHeight / 2);
            
            // Jika Dino jatuh dari atas menimpa tanah
            if (getY() <= newY + 20 && vSpeed >= 0) {
                setLocation(getX(), newY);
                vSpeed = 0;
                isJumping = false;
            }
        }
        
        // Batas pengaman bawah world
        if (getY() > 410) {
            setLocation(getX(), 410);
            vSpeed = 0;
            isJumping = false;
        }
    }
}