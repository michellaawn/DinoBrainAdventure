import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class time here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class time extends Tileset
{
    /**
     * Act - do whatever the time wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public time()
    {
       super("timee2.png");
       getImage().scale(32, 32);
    }
}
