import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class grass1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class grass1 extends Actor
{
    public grass1()
    {
        GreenfootImage img = getImage();
        if (img != null) {
            img.scale(60, 60); // Sesuaikan ukuran balok tanah
            setImage(img);
        }
    }
    
    public void act()
    {
    }
}
