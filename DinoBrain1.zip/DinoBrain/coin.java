import greenfoot.*;

public class coin extends Actor
{
    public coin()
    {
        // Mengatur ukuran koin agar pas
        GreenfootImage img = getImage();
        if (img != null) {
            img.scale(25, 25);
            setImage(img);
        }
    }

    public void act()
    {
        checkCollision();
    }

    private void checkCollision()
    {
        // Cek apakah koin bersentuhan dengan Dino
        Actor dino = getOneIntersectingObject(Dino.class);
        if (dino != null) {
            // Mengambil referensi World dan melakukan casting ke Level1World
            World world = getWorld();
            if (world instanceof Level1World) {
                Level1World level1 = (Level1World) world;
                level1.addScore(10); // Menambah skor sebanyak 10
            }
            
            // Hapus koin dari layar
            getWorld().removeObject(this);
        }
    }
}