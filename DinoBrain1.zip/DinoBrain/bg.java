import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class bg here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class bg extends World
{

    /**
     * Constructor for objects of class bg.
     * 
     */
    public bg()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 450, 1);
        GreenfootImage bg = new GreenfootImage("Pixel Art Sky With Cloud Horizon.png");
        bg.scale(800, 450);
        setBackground(bg);
        
        addObject(new Logo(), 400, 130);
        addObject(new Start(), 400, 270);
        addObject(new Exit(), 400, 320);
        addObject(new Learn(), 400, 370);
    }
}
