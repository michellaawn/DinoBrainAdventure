
import greenfoot.*;

public class TransitionLevel1 extends World
{
    private int timer = 0;
    private final int loadingTime = 300;

    private GreenfootImage originalBG;
    private GreenfootImage logo;

    public TransitionLevel1()
    {
        super(800, 450, 1);
        originalBG = new GreenfootImage(
            "pagi.png"
        );
        originalBG.scale(800, 450);
        
        logo = new GreenfootImage("LOGODINO.png");
        logo.scale(360, 151);

        drawScreen(0);

        // Dino berjalan
        addObject(new Dinowalk(), getWidth() / 2, 325);
    }

    private void drawScreen(int progress)
    {
        GreenfootImage bg = new GreenfootImage(originalBG);
        bg.setColor(new Color(0, 0, 0, 155));
        bg.fillRect(0, 0, 800, 450);

        bg.drawImage(logo, 220, 35);
        bg.setFont(new Font("Arial", true, false, 23));
        bg.setColor(Color.BLACK);
        bg.drawString(
            "LEVEL 01 - THE FOREST OF KNOWLEDGE",
            185, 235
        );

        bg.setColor(Color.WHITE);
        bg.drawString(
            "LEVEL 01 - THE FOREST OF KNOWLEDGE",
            182, 232
        );

        bg.setFont(new Font("Arial", false, false, 17));
        bg.setColor(new Color(230, 230, 230));
        bg.drawString(
            "Your next adventure is waiting...",
            265, 275
        );

        bg.setFont(new Font("Arial", true, false, 16));
        bg.setColor(new Color(255, 220, 120));
        bg.drawString(
            "LOADING... " + progress + "%",
            340, 390
        );

        bg.setColor(new Color(30, 35, 35));
        bg.fillRect(180, 405, 440, 13);

        bg.setColor(new Color(255, 195, 65));
        bg.fillRect(
            180, 405,
            440 * progress / 100, 13
        );

        bg.setColor(Color.WHITE);
        bg.drawRect(180, 405, 440, 13);

        setBackground(bg);
    }

    public void act()
    {
        timer++;

        int progress = Math.min(
            100,
            timer * 100 / loadingTime
        );

        drawScreen(progress);

        if (timer >= loadingTime)
        {
            Greenfoot.setWorld(new Level1World());
        }
    }
}
