import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class ButtonsHome here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class ButtonsHome extends Buttons
{
    /**
     * Act - do whatever the ButtonsHome wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
       if (Greenfoot.mouseClicked(this)) {
    }
}
}
