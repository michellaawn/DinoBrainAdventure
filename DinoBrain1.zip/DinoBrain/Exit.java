import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class exit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Exit extends Beranda_Logo
{
    /**
     * Act - do whatever the exit wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Exit()
    {
        GreenfootImage img = new GreenfootImage(getImage());
        int lebarBaru = 150;
        int tinggiBaru = img.getHeight() * lebarBaru / img.getWidth();
        img.scale(lebarBaru, tinggiBaru);
        setImage(img);
    }
}
