import greenfoot.*;

public class Dino extends Actor
{
    private int vSpeed = 0;
    private int acceleration = 1;
    private int jumpStrength = -11;
    private boolean isDead = false;
    
    private GreenfootImage[] walkImages = new GreenfootImage[3];
    private int walkIndex = 0;
    private int walkCounter = 0;
    
    private GreenfootImage[] jumpImages = new GreenfootImage[4];
    private GreenfootImage[] deadImages = new GreenfootImage[3];

    public Dino()
    {
        for (int i = 0; i < 3; i++) {
            walkImages[i] = new GreenfootImage("walk" + (i + 1) + ".png");
            walkImages[i].scale(70, 70);
        }
        
        for (int i = 0; i < 4; i++) {
            jumpImages[i] = new GreenfootImage("jump" + (i + 1) + ".png");
            jumpImages[i].scale(70, 70);
        }
        
        for (int i = 0; i < 3; i++) {
            deadImages[i] = new GreenfootImage("dead" + (i + 1) + ".png");
            deadImages[i].scale(70, 70);
        }
        
        setImage(walkImages[0]);
    }

    public void act()
    {
        if (isDead) return;

        checkKeys();
        fall();
        checkHazards();
    }

    private void checkKeys()
    {
        boolean moving = false;
        
        if (Greenfoot.isKeyDown("left") || Greenfoot.isKeyDown("a")) {
            setLocation(getX() - 4, getY());
            moving = true;
        }
        if (Greenfoot.isKeyDown("right") || Greenfoot.isKeyDown("d")) {
            setLocation(getX() + 4, getY());
            moving = true;
        }
        
        if ((Greenfoot.isKeyDown("space") || Greenfoot.isKeyDown("up")) && onGround()) {
            vSpeed = jumpStrength;
            setLocation(getX(), getY() - 5);
        }
        
        if (!onGround()) {
            setImage(jumpImages[0]);
        } else if (moving) {
            walkCounter++;
            if (walkCounter > 8) {
                walkIndex = (walkIndex + 1) % walkImages.length;
                setImage(walkImages[walkIndex]);
                walkCounter = 0;
            }
        } else {
            setImage(walkImages[0]);
        }
    }

    private void fall()
    {
        setLocation(getX(), getY() + vSpeed);
        vSpeed += acceleration;
        
        if (vSpeed > 0) {
            Actor ground = getOneObjectAtOffset(0, getImage().getHeight() / 2, grass2.class);
            Actor ground1 = getOneObjectAtOffset(0, getImage().getHeight() / 2, grass1.class);
            Actor diagGround = getOneObjectAtOffset(0, getImage().getHeight() / 2, dggrass.class);
            
            if (ground != null || ground1 != null || diagGround != null) {
                Actor currentGround = (ground != null) ? ground : (ground1 != null ? ground1 : diagGround);
                int groundTop = currentGround.getY() - (currentGround.getImage().getHeight() / 2);
                
                int offset = 6;
                if (currentGround instanceof dggrass) {
                    offset = 10;
                }
                
                setLocation(getX(), groundTop - (getImage().getHeight() / 2) + offset);
                vSpeed = 0;
            }
        }
        
        if (vSpeed < 0) {
            Actor ceiling = getOneObjectAtOffset(0, -getImage().getHeight() / 2, grass2.class);
            if (ceiling != null) {
                int ceilingBottom = ceiling.getY() + (ceiling.getImage().getHeight() / 2);
                setLocation(getX(), ceilingBottom + (getImage().getHeight() / 2));
                vSpeed = 0;
            }
        }
    }

    private boolean onGround()
    {
        Actor ground = getOneObjectAtOffset(0, getImage().getHeight() / 2 + 3, grass2.class);
        Actor ground1 = getOneObjectAtOffset(0, getImage().getHeight() / 2 + 3, grass1.class);
        Actor diagGround = getOneObjectAtOffset(0, getImage().getHeight() / 2 + 3, dggrass.class);
        
        return ground != null || ground1 != null || diagGround != null;
    }

    private void checkHazards()
    {
        Actor hazard = getOneIntersectingObject(air.class);
        Actor spike = getOneIntersectingObject(spikes.class);
        
        if (hazard != null || spike != null) {
            die();
        }
    }

    private void die()
    {
        isDead = true;
        setImage(deadImages[2]);
        
        World world = getWorld();
        if (world instanceof Level1World) {
            Level1World level = (Level1World) world;
            level.loseLife();
            
            if (level.getLives() > 0) {
                Greenfoot.delay(30);
                setLocation(60, 350);
                vSpeed = 0;
                isDead = false;
            }
        }
    }
}