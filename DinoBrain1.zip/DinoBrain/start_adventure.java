import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class start_adventure here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class start_adventure extends dialog
{
    public start_adventure(){
        GreenfootImage img = new GreenfootImage("start_adventure.png");
        img.scale(200, 50);
        setImage(img);
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)){
            Greenfoot.setWorld(new TransitionLevel1());
        }
    }
}
