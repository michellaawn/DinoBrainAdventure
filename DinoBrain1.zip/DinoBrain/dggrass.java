import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class dggrass here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class dggrass extends Actor
{
    /**
     * Act - do whatever the dggrass wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public dggrass()
    {
        GreenfootImage img = getImage();
        if (img != null) {
            img.scale(60, 60); 
            setImage(img);
        }
    }
}