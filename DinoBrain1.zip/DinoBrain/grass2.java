import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class grass2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class grass2 extends Actor
{
    /**
     * Act - do whatever the grass2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
     public grass2()
    {
        GreenfootImage img = getImage();
        if (img != null) {
            img.scale(60, 60); // Sesuaikan ukuran balok tanah
            setImage(img);
        }
    }
    public void act()
    {
        // Add your action code here.
    }
}
