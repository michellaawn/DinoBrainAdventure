import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class GAMESTART here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class GAMESTART extends World
{

    /**
     * Constructor for objects of class GAMESTART.
     * 
     */
    public GAMESTART()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(800, 450, 1);
        GreenfootImage bg = new GreenfootImage("latarpagi.jpg");
        bg.scale(getWidth(), getHeight());
        setBackground(bg);
        
        String[] teksCerita = {
            "I live in a beautiful forest filled\nwith trees, flowers.",
            "and wonderful creatures.\nThis forest has always been my home.",
            "I have always been curious \nabout the world around me.",
            "I love exploring new places and\nlearning about nature.",
            "But one day, I wandered too far\ninto the unknown.",
            "Oh no... everything looks unfamiliar.\nAm I lost?",
            "I'm a bit scared, but I can't give up.\nI must find my way back!",
            "It's time to be brave.\nLet my journey begin!"
        };
        box dialog = new box(teksCerita, "dialog2dino.png");
        addObject(dialog, 400, 310);
        
        next tombolNext = new next(dialog, "next.png");
        addObject(tombolNext, 400, 390);
    }
    
}
