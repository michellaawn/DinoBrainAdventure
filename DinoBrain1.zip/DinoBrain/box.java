import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class box here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class box extends dialog
{
    private String[] teks;
    private int indeksTeks = 0;
    private String fileGambar;
    
    public box (String[] teks, String fileGambar){
        this.teks = teks;
        this.fileGambar = fileGambar;
        renderDialog();
    }
    public void lanjutTeks()
    {
        indeksTeks++;
        
        if (indeksTeks < teks.length) {
            renderDialog(); // Tampilkan kalimat selanjutnya
            
            if (indeksTeks == teks.length - 1){
                getWorld().removeObjects(getWorld().getObjects(next.class));
                getWorld().addObject(new start_adventure(), 400, 390);
            }
        }
    }
    private void renderDialog()
    {
        GreenfootImage img = new GreenfootImage(fileGambar);
        

        // Pengaturan font dan warna teks
        img.setColor(Color.WHITE); 
        img.setFont(new greenfoot.Font("Courier New", true, false, 18)); 

        // Menuliskan teks di sebelah kanan gambar Dino
        // Angka 220 = jarak horizontal dari kiri (agak ke kanan dari foto Dino)
        // Angka 70 = jarak vertikal dari atas
        img.drawString(teks[indeksTeks], 220, 110);

        setImage(img);
    }
}
