import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class learn here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Learn extends Beranda_Logo
{
    /**
     * Act - do whatever the learn wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Learn()
    {
        GreenfootImage img = new GreenfootImage(getImage());
        int lebarBaru = 150;
        int tinggiBaru = img.getHeight() * lebarBaru / img.getWidth();
        img.scale(lebarBaru, tinggiBaru);
        setImage(img);// Add your action code here.
    }
    public void act()
    {
    if (Greenfoot.mouseClicked(this))
    {
        Greenfoot.setWorld(new LearnGame());
    }
    }
}
