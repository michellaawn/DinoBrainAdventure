import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class air here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class air extends Tileset
{
    /**
     * Act - do whatever the air wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public air()
    {
        super("air.png");
    }
}
