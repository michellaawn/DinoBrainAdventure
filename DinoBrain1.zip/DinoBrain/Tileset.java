import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Tileset here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
import greenfoot.*;

public class Tileset extends Actor
{
    public Tileset(String imageName)
    {
        setImage(imageName);
    }
}
