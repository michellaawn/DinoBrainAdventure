import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class tombol_ok here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class tombol_ok extends tutorial
{
    private Actor panel;
    public tombol_ok(Actor panel){
        this.panel = panel;
    }
    public void act()
    {
        if (Greenfoot.mouseClicked(this)){
            World currentWorld = getWorld();
            
            //Jika sedang di menu Learn -> Kembali ke Menu Utama
            if (currentWorld instanceof LearnGame) {
                Greenfoot.setWorld(new bg()); // Ganti 'MainMenu' sesuai nama class World menu awalmu
            } 
            // ika sedang di Level1 -> Hapus panel & tombol OK agar game dimulai
            else if (currentWorld instanceof Level1World) {
                if (panel != null) {
                    currentWorld.removeObject(panel); // Hapus panel tutorial
                }
                currentWorld.removeObject(this); // Hapus tombol OK ini dari layar
            }
        }
    }
}
