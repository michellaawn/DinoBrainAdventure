import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class logo here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Logo extends Beranda_Logo
{
    /**
     * Act - do whatever the logo wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Logo()
    {
        GreenfootImage img = new GreenfootImage(getImage());
        int lebarBaru = 500;
        int tinggiBaru = img.getHeight() * lebarBaru / img.getWidth();
        img.scale(lebarBaru, tinggiBaru);
        setImage(img);
    }
}
